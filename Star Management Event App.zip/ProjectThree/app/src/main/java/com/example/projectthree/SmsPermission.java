package com.example.projectthree;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.content.Intent;
import android.widget.ImageView;
import android.view.View;


public class SmsPermission extends AppCompatActivity {

    private static final int PERMISSION_SEND_SMS = 123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.permission_request);

        Switch smsSwitch = findViewById(R.id.switch1);
        ImageView imageView3 = findViewById(R.id.imageView3);
        TextView textViewExplanation = findViewById(R.id.textViewExplanation);


        smsSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                // Check if the SMS permission has been granted
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                    // Permission not granted, request it
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, PERMISSION_SEND_SMS);
                    textViewExplanation.setText("Requesting permission...");
                } else {
                    // Permission already granted, enable SMS feature
                    textViewExplanation.setText("SMS notifications enabled.");
                }
            } else {
                // Switch turned off, disable SMS feature
                textViewExplanation.setText("SMS notifications disabled.");
            }
        });
        imageView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SmsPermission.this, EventListActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        TextView textViewExplanation = findViewById(R.id.textViewExplanation);

        if (requestCode == PERMISSION_SEND_SMS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, SMS notifications can be enabled
                textViewExplanation.setText("SMS notifications enabled.");
            } else {
                // Permission denied, disable the SMS feature
                textViewExplanation.setText("Permission not granted. Enable SMS notifications to receive updates.");
                Switch smsSwitch = findViewById(R.id.switch1);
                smsSwitch.setChecked(false);
            }
        }
    }
}
