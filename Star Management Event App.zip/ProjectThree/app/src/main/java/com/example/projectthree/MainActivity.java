package com.example.projectthree; // Replace with your actual package name

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private Button createAccountButton;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);
        loginButton = findViewById(R.id.login_button);
        createAccountButton = findViewById(R.id.create_account_button);

        // Initialize DBHelper
        dbHelper = new DBHelper(this);

        // Set onClickListeners for the buttons
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginUser();
            }
        });

        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createAccount();
            }
        });
    }

    private void loginUser() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(MainActivity.this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check if user exists and password matches
        if (dbHelper.checkUser(username, password)) {
            // Login success
            Toast.makeText(MainActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
            // Navigate to next activity or main screen here if needed
            Intent intent = new Intent(MainActivity.this, EventListActivity.class);
            startActivity(intent);
            finish();
        } else {
            // Login failure
            Toast.makeText(MainActivity.this, "Login failed. Check your username and password", Toast.LENGTH_SHORT).show();
        }
    }

    private void createAccount() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(MainActivity.this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // Insert new user into database
        dbHelper.addUser(username, password);
        Toast.makeText(MainActivity.this, "Account created successfully", Toast.LENGTH_SHORT).show();

        // Clear the input fields or navigate to the login screen/main activity
        usernameEditText.setText("");
        passwordEditText.setText("");


    }
}
