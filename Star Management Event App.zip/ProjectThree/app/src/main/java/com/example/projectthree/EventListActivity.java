package com.example.projectthree;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class EventListActivity extends AppCompatActivity implements EventAdapter.OnEventListener {

    private RecyclerView recyclerView;
    private EventAdapter adapter;
    private DBHelper dbHelper;
    private Button addDataButton;
    private Button smsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data_display);

        recyclerView = findViewById(R.id.recyclerView);
        addDataButton = findViewById(R.id.addDataButton);
        smsButton = findViewById(R.id.smsButton);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        dbHelper = new DBHelper(this);
        Cursor cursor = dbHelper.getAllEvents();

        adapter = new EventAdapter(this, cursor, this);
        recyclerView.setAdapter(adapter);

        addDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(EventListActivity.this, AddEventActivity.class));
            }
        });

        smsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // No complex permission checking inside `EventListActivity` anymore
                startActivity(new Intent(EventListActivity.this, SmsPermission.class));
            }
        });
    }





    @Override
    protected void onStart() {
        super.onStart();
        adapter.swapCursor(dbHelper.getAllEvents());
    }

    public void deleteEvent(int id) {
        dbHelper.deleteEvent(id);
        adapter.swapCursor(dbHelper.getAllEvents()); // Refresh the list
    }

    @Override
    public void onDeleteEvent(int id) {
        deleteEvent(id);
    }
}
