package com.example.projectthree;

import android.content.Context;
import android.database.Cursor;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventViewHolder> {

    private Context context;
    private Cursor cursor;
    private OnEventListener eventListener;

    // Define an interface for event actions like deletion
    public interface OnEventListener {
        void onDeleteEvent(int id);
    }

    public EventAdapter(Context context, Cursor cursor, OnEventListener eventListener) {
        this.context = context;
        this.cursor = cursor;
        this.eventListener = eventListener;
    }

    public class EventViewHolder extends RecyclerView.ViewHolder {
            public TextView eventName;
            public TextView eventDate;
            public Button deleteButton;
            public TextView eventDescription;


        public EventViewHolder(View itemView) {
                super(itemView);
                eventName = itemView.findViewById(R.id.itemName);
                eventDate = itemView.findViewById(R.id.itemDate);
                deleteButton = itemView.findViewById(R.id.deleteButton);
                eventDescription = itemView.findViewById(R.id.itemDescription);


            deleteButton.setOnClickListener(view -> {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION && cursor.moveToPosition(position)) {
                        // Use getColumnIndexOrThrow to ensure the column exists; catch the exception if not
                        try {
                            int idIndex = cursor.getColumnIndexOrThrow(DBHelper.COLUMN_EVENT_ID);
                            int id = cursor.getInt(idIndex);
                            eventListener.onDeleteEvent(id);
                        } catch (IllegalArgumentException e) {
                            // Handle the case where the column does not exist
                            // This block can be used to log the error or notify the user
                            Log.e("EventAdapter", "Column not found", e);
                        }
                    }
                });
            }
        }


        @Override
    public EventViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_data, parent, false);
        return new EventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(EventViewHolder holder, int position) {
        if (!cursor.moveToPosition(position)) {
            return;
        }

        int idIndex = cursor.getColumnIndex(DBHelper.COLUMN_EVENT_ID);
        int nameIndex = cursor.getColumnIndex(DBHelper.COLUMN_EVENT_NAME);
        int dateIndex = cursor.getColumnIndex(DBHelper.COLUMN_EVENT_DATE);
        int descriptionIndex = cursor.getColumnIndexOrThrow(DBHelper.COLUMN_EVENT_DESCRIPTION);

        if (idIndex != -1 && nameIndex != -1 && dateIndex != -1) {
            String name = cursor.getString(nameIndex);
            String date = cursor.getString(dateIndex);
            String description = cursor.getString(descriptionIndex);
            holder.eventName.setText(name);
            holder.eventDate.setText(date);
            holder.eventDescription.setText(description);




        }
    }


    @Override
    public int getItemCount() {
        return cursor.getCount();
    }

    public void swapCursor(Cursor newCursor) {
        if (cursor != null) {
            cursor.close();
        }
        cursor = newCursor;
        if (newCursor != null) {
            notifyDataSetChanged();
        }
    }
}
