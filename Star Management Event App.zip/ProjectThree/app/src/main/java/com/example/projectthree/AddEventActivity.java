package com.example.projectthree;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class AddEventActivity extends AppCompatActivity {

    private EditText eventName, eventDate, eventDescription;
    private Button saveEventButton;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_event);

        eventName = findViewById(R.id.eventName);
        eventDate = findViewById(R.id.eventDate);
        eventDescription = findViewById(R.id.eventDescription);
        saveEventButton = findViewById(R.id.saveEventButton);

        dbHelper = new DBHelper(this);

        saveEventButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveEvent();
            }
        });
    }

    private void saveEvent() {
        String name = eventName.getText().toString().trim();
        String date = eventDate.getText().toString().trim();
        String description = eventDescription.getText().toString().trim();

        dbHelper.addEvent(name, date, description);

        finish(); // Return to the previous activity
    }
}
